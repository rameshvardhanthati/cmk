sap.ui.define(["sap/fe/core/AppComponent"], function(AppComponent) {
    'use strict';

    return AppComponent.extend("com.changemaker.projectlist.projectlist.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
